//Tanishk Nalamolu
//ICS4U0
//10/17/2016
//Library Assignment Book Class

public class Book {

	private String title;//The title of the book
	private String author;//The author of the book
	private String ISBN;//The ISBN of the book
	private String category;//The category of the book
	private double cost;//The cost of the book
	private double rating; //The rating of the book
	private boolean bookOut;//If the book is out of the library

    //Book constructor that assigns book info: title, author, rating, cost, category, isbn, expireDate, copies, availability, daysOut
    //@param: title: string variable for the title of the book
    //@param: author: string variable for author of book
    //@param: rating: double variable of reader rating of the book 
    //@param: cost: double variable of the cost of the book
    //@param: ISBN: String variable of book's ISBN code
    //@param: copies: int variable of number of available copies of book
	public Book(String title, String author, String ISBN, String category,
			double cost, double rating, boolean bookOut) {
		this.title = title;
		this.author = author;
		this.ISBN = ISBN;
		this.category = category;
		this.cost = cost;
		this.rating = rating;
		this.bookOut = bookOut;
	}

    //Method that returns the title of the book
    //@return: returns the books title
	public String getTitle() {
		return title;
	}

    //Method that gets the author of the book
    //@return: returns the books author
	public String getAuthor() {
		return author;
	}

    //Method that gets the ISBN code of book
    //@return: returns the book's ISBN code
	public String getISBN() {
		return ISBN;
	}

    //Method that gets the books category
    //@return: returns the category of the book
	public String getCategory() {
		return category;
	}
	
    //Method that returns the cost of the book
    //@return: returns the cost of the book
	public double getCost() {
		return cost;
	}

    //Method that gets the rating of the book
    //@return: returns the books rating
	public double getRating() {
		return rating;
	}

	//Gets the status of the book. If its inside the library or checked out
	//@return: returns the boolean bookOut
	public boolean getBookOut() {
		// TODO Auto-generated method stub
		return bookOut;
	}

	//Sets if the book is out of the library or not
	//@param: boolean value
	public void setBookOut(boolean b) {
		// TODO Auto-generated method stub
		this.bookOut = b;
	}

}
