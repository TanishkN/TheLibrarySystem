//Tanishk Nalamolu
//ICS4U0
//10/17/2016
//Library Assignment Library Class

//Imports Used
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import java.awt.Font;

public class LibraryProject {

	//Lists containing all of the students and books registered in the library
	ArrayList<User> listOfUsers = new ArrayList<User>();
	ArrayList<Book> listOfBooks = new ArrayList<Book>();

	//All the panels used in the UI
	private JPanel MasterPanel = new JPanel();
	private JPanel homePanel = new JPanel();
	private JPanel CreateUserPanel = new JPanel();
	private JPanel DeleteBookPanel;
	private JPanel SignIn_SignOut;
	private JPanel CreateBookPanel;
	private JPanel LookUpBooksPanel;
	private JPanel CompareBooksPanel;
	private JPanel DeleteUserPanel;

	CardLayout cardLayout = new CardLayout();//Card layout
	
	//Hard Coded Users and Book objects
	User user_test1 = new User("499693", "Tanishk", "Nalamolu", 0.0);
	User user_test2 = new User("200", "Santa", "Clause", 0.0);
	User user_test3 = new User("3", "James", "Remary", 0.0);
	User user_test4 = new User("4", "John", "Smith", 0.0);
	User user_test5 = new User("5", "Adam", "Hodgekins", 0.0);
	User user_test6 = new User("6", "Philipe", "Louis", 0.0);
	User user_test7 = new User("7", "Kyle", "Walk", 0.0);

	Book book_test1 = new Book("Money Talks: The Ultimate Guide", "Tanishk Nalamolu", "A100", "Finance", 5, 4, false);
	Book book_test2 = new Book("Harry Potter", "J.K Rowling", "A150", "Fantasy", 20, 4.5, false);
	Book book_test3 = new Book("Romeo and Juliet", "ShakeSpeare", "A160", "Tragedy", 10, 3.5, false);

	// private boolean mainScreen = true;
	private boolean isTaken = false;// If user has already been taken
	int numberOfBooksOut = 0;

	//The frame all components and UI are inside 
	private JFrame frame = new JFrame("Library System");

	JButton b = new JButton("Test Button");
	private JTextField std_Number;
	private JTextField std_FName;
	private JTextField std_LName;

	//Initialization of Text Area(Screen where information is displayed)
	private JTextArea userList = new JTextArea();
	private JTextArea txtArea_CompareBooks = new JTextArea();
	private JTextArea textArea_SearchBook = new JTextArea();
	private JTextArea bookList;

	//All Buttons used in the UI
	private JButton viewUserButton;
	private JButton btnDeleteUser;
	private JButton btnDeleteBook;
	private JButton btnCreateBook_Enter;
	private JButton btnNewButton_1;
	private JButton button_3;
	private JButton button_4;
	private JButton button_5;
	private JButton button_6;
	private JButton btn_compareBooks;
	private JButton btn_LookUp;
	private JButton button;
	private JButton button_1;
	private JButton btnCategory;
	private JButton btnAuthor;
	private JButton btnDeleteBook_Delete;
	private JButton btnCompare;
	
	//All Labels used in the UI
	private JLabel lblStudentNumber;
	private JLabel lblStudentFirstName;
	private JLabel lblStudentLastName;
	private JLabel lblNewLabel;
	private JLabel lblCheckOut;
	private JLabel lblDeleteBook;	
	private JLabel lblSignIn_StdNumber;
	private JLabel lblSignIn_ISBN;
	private JLabel lblSignIn_DaysOut;
	private JLabel lblSignOut_StdNumber;
	private JLabel lblSignOut_ISBN;
	private JLabel lblDeleteBook_ISBN;
	private JLabel lblNewLabel_3;
	private JLabel lblCategory_1;
	private JLabel lblNewLabel_1;
	
	//All User Input TextFields used in the UI
	private JTextField deleteUser_StdNumber;
	private JTextField book_Name;
	private JTextField book_Author;
	private JTextField book_Category;
	private JTextField book_ISBN;
	private JTextField book_Rating;
	private JTextField book_Cost;
	private JTextField signIn_StdNumber;
	private JTextField signIn_ISBN;
	private JTextField signIn_DaysOut;
	private JTextField signOut_StdNumber;
	private JTextField signOut_ISBN;
	private JTextField txtDeleteBook;
	private JTextField textField_ISBN1;
	private JTextField textField_ISBN2;
	private JTextField categorySearch;
	private JTextField authorSearch;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LibraryProject window = new LibraryProject();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public LibraryProject() {
		initialize();// Calling Initialize
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame.setResizable(false);
		frame.setBounds(100, 100, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.getContentPane().add(MasterPanel);
		
		/*TEST OBJECTS
		listOfUsers.add(user_test1);
		// listOfUsers.add(user_test2);
		// listOfUsers.add(user_test3);
		// listOfUsers.add(user_test4);
		// listOfUsers.add(user_test5);
		// listOfUsers.add(user_test6);
		// listOfUsers.add(user_test7);

		listOfBooks.add(book_test1);
		listOfBooks.add(book_test2);
		// listOfBooks.add(book_test3);
*/
		MasterPanel.setLayout(cardLayout);
		MasterPanel.add(homePanel, "Home");
		homePanel.setLayout(null);

		// For User Button on Home Panel
		JButton btnCreateUser = new JButton("Create User/View");
		btnCreateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();//Remove all items on that panel
				MasterPanel.add(CreateUserPanel).setVisible(true);//Add a panel to the screen
			}
		});
		btnCreateUser.setBounds(23, 86, 134, 79);
		homePanel.add(btnCreateUser);
		
		// For Book Button on Home Panel
		JButton btnCreateBook = new JButton("Create Book/View");
		btnCreateBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(CreateBookPanel).setVisible(true);
			}
		});
		btnCreateBook.setBounds(428, 86, 134, 79);
		homePanel.add(btnCreateBook);

		// For General Features Button on Home Panel
		JButton btnBookSign = new JButton("SignIn/SignOut");
		btnBookSign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(SignIn_SignOut).setVisible(true);
			}
		});
		btnBookSign.setBounds(225, 148, 134, 79);
		homePanel.add(btnBookSign);

		btnDeleteUser = new JButton("Delete User");
		btnDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(DeleteUserPanel).setVisible(true);
			}
		});
		btnDeleteUser.setBounds(23, 204, 134, 66);
		homePanel.add(btnDeleteUser);

		btnDeleteBook = new JButton("Delete Book");
		btnDeleteBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(DeleteBookPanel).setVisible(true);
			}
		});
		btnDeleteBook.setBounds(428, 205, 134, 65);
		homePanel.add(btnDeleteBook);

		btn_compareBooks = new JButton("Compare Books");
		btn_compareBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(CompareBooksPanel).setVisible(true);
			}
		});
		btn_compareBooks.setBounds(114, 337, 134, 23);
		homePanel.add(btn_compareBooks);

		btn_LookUp = new JButton("LookUp Books");
		btn_LookUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MasterPanel.removeAll();
				MasterPanel.add(LookUpBooksPanel).setVisible(true);

			}
		});
		btn_LookUp.setBounds(334, 337, 119, 23);
		homePanel.add(btn_LookUp);
		
		JLabel lblNewLabel_4 = new JLabel("Welcome to the Library System");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(149, 32, 279, 25);
		homePanel.add(lblNewLabel_4);

		MasterPanel.add(CreateUserPanel);
		SpringLayout sl_CreateUserPanel = new SpringLayout();
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, userList, 21, SpringLayout.NORTH, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, userList, 331, SpringLayout.WEST, CreateUserPanel);
		CreateUserPanel.setLayout(sl_CreateUserPanel);
		// For switching
		// to each card
		// layout

		std_Number = new JTextField();
		CreateUserPanel.add(std_Number);
		std_Number.setColumns(10);

		std_FName = new JTextField();
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, std_Number, 0, SpringLayout.WEST, std_FName);
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, std_Number, -44, SpringLayout.NORTH, std_FName);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, std_Number, 0, SpringLayout.EAST, std_FName);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, std_FName, -36, SpringLayout.WEST, userList);
		CreateUserPanel.add(std_FName);
		std_FName.setColumns(10);

		std_LName = new JTextField();
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, std_LName, -36, SpringLayout.WEST, userList);
		CreateUserPanel.add(std_LName);
		std_LName.setColumns(10);

		viewUserButton = new JButton("view");
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, viewUserButton, 10, SpringLayout.WEST, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, viewUserButton, -10, SpringLayout.SOUTH, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, viewUserButton, -488, SpringLayout.EAST, CreateUserPanel);

		// When View is clicked in UserPanel
		viewUserButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// for (int count = 0; count < listOfUsers.size(); count++) {
				// System.out.println(listOfUsers.get(1).toString());
				// }
				// for (int count = 0; count < listOfUsers.size(); count++) {
				// studentQuery.add(listOfUsers.get(count));
				// System.out.println("Student Number: " +
				// listOfUsers.get(0).toString());
				// System.out.println("Student First Name: " +
				// listOfUsers.get(count));
				// System.out.println("Retrieved element is = " + count);

				// int retval=listOfUsers.get(3);
				// System.out.println("Retrieved element is = " + retval);
				// System.out.println("Student Last Name: " +
				// listOfUsers.get(2).toString());
				// System.out.println("Student Fine: " +
				// listOfUsers.get(3).toString());
				// }
				// System.out.println(listOfUsers.get(0));
				// System.out.println(listOfUsers.get(0).toString());

				userList.setText("");
				User u;
				Book uBooks;

				for (int i = 0; i < listOfUsers.size(); i++) {
					u = listOfUsers.get(i);
					userList.append("Student Number: " + u.getStudentNumber() + "\n" + "First Name " + u.getFirstName()
							+ "\n" + "Last Name " + u.getLastName() + "\n" + "Fine: " + u.getFines() + "\n");

					for (int c = 0; c < u.books.size(); c++) {

						u = listOfUsers.get(i);
						if (u.books.size() > 0) {
							// i=i-1;
							uBooks = (u.books).get(c);
							userList.append("Books Taken Out: " + uBooks.getTitle() + "\n");
						}
					}
				}

			}
		});
		CreateUserPanel.add(viewUserButton);

		JButton enterButton = new JButton("Enter");
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, enterButton, -10, SpringLayout.SOUTH, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, userList, -35, SpringLayout.NORTH, enterButton);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, enterButton, -28, SpringLayout.EAST, CreateUserPanel);
		CreateUserPanel.add(enterButton);

		JButton homeButton = new JButton("Home");
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, homeButton, 10, SpringLayout.WEST, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, homeButton, -488, SpringLayout.EAST, CreateUserPanel);
		homeButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// MasterPanel.removeAll();
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
				// cardLayout.show(MasterPanel, "Home");
			}
		});
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, homeButton, 10, SpringLayout.NORTH, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, homeButton, -328, SpringLayout.SOUTH, CreateUserPanel);
		CreateUserPanel.add(homeButton);

		lblStudentNumber = new JLabel("Student Number:");
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, lblStudentNumber, 3, SpringLayout.NORTH, std_Number);
		CreateUserPanel.add(lblStudentNumber);

		lblStudentFirstName = new JLabel("Student First Name:");
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, lblStudentNumber, 0, SpringLayout.WEST,
				lblStudentFirstName);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, std_FName, 25, SpringLayout.EAST, lblStudentFirstName);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, lblStudentFirstName, 53, SpringLayout.WEST,
				CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, std_FName, -3, SpringLayout.NORTH, lblStudentFirstName);
		CreateUserPanel.add(lblStudentFirstName);

		lblStudentLastName = new JLabel("Student Last Name:");
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, std_LName, 26, SpringLayout.EAST, lblStudentLastName);
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, lblStudentLastName, 218, SpringLayout.NORTH,
				CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, lblStudentLastName, 53, SpringLayout.WEST, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, lblStudentFirstName, -46, SpringLayout.NORTH,
				lblStudentLastName);
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, std_LName, -3, SpringLayout.NORTH, lblStudentLastName);
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, viewUserButton, 96, SpringLayout.SOUTH,
				lblStudentLastName);
		CreateUserPanel.add(lblStudentLastName);

		btnNewButton_1 = new JButton("Clear");
		sl_CreateUserPanel.putConstraint(SpringLayout.SOUTH, btnNewButton_1, -10, SpringLayout.SOUTH, CreateUserPanel);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, enterButton, 26, SpringLayout.EAST, btnNewButton_1);
		sl_CreateUserPanel.putConstraint(SpringLayout.WEST, btnNewButton_1, 273, SpringLayout.WEST, CreateUserPanel);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userList.setText("");

			}
		});
		CreateUserPanel.add(btnNewButton_1);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, userList, -27, SpringLayout.EAST, CreateUserPanel);
		CreateUserPanel.add(userList);

		JLabel lblNewLabel_2 = new JLabel("Create User/View");
		sl_CreateUserPanel.putConstraint(SpringLayout.NORTH, lblNewLabel_2, -2, SpringLayout.NORTH, userList);
		sl_CreateUserPanel.putConstraint(SpringLayout.EAST, lblNewLabel_2, 0, SpringLayout.EAST, std_Number);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		CreateUserPanel.add(lblNewLabel_2);

		DeleteUserPanel = new JPanel();
		MasterPanel.add(DeleteUserPanel, "name_12672113819130");
		SpringLayout sl_DeleteUserPanel = new SpringLayout();
		DeleteUserPanel.setLayout(sl_DeleteUserPanel);

		deleteUser_StdNumber = new JTextField();
		sl_DeleteUserPanel.putConstraint(SpringLayout.NORTH, deleteUser_StdNumber, 121, SpringLayout.NORTH,
				DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.WEST, deleteUser_StdNumber, 225, SpringLayout.WEST,
				DeleteUserPanel);
		DeleteUserPanel.add(deleteUser_StdNumber);
		deleteUser_StdNumber.setColumns(10);

		JLabel lblDeleteUser = new JLabel("Delete User");
		sl_DeleteUserPanel.putConstraint(SpringLayout.NORTH, lblDeleteUser, 34, SpringLayout.NORTH, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.WEST, lblDeleteUser, 238, SpringLayout.WEST, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.SOUTH, lblDeleteUser, 62, SpringLayout.NORTH, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.EAST, lblDeleteUser, -241, SpringLayout.EAST, DeleteUserPanel);
		lblDeleteUser.setHorizontalAlignment(SwingConstants.CENTER);
		DeleteUserPanel.add(lblDeleteUser);

		JLabel lblDeleteUser_StudentNumber = new JLabel("Student Number:");
		sl_DeleteUserPanel.putConstraint(SpringLayout.NORTH, lblDeleteUser_StudentNumber, 3, SpringLayout.NORTH,
				deleteUser_StdNumber);
		sl_DeleteUserPanel.putConstraint(SpringLayout.EAST, lblDeleteUser_StudentNumber, -42, SpringLayout.WEST,
				deleteUser_StdNumber);
		DeleteUserPanel.add(lblDeleteUser_StudentNumber);

		JButton btnDeleteUser_Enter = new JButton("Enter");
		sl_DeleteUserPanel.putConstraint(SpringLayout.SOUTH, btnDeleteUser_Enter, -31, SpringLayout.SOUTH,
				DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.EAST, btnDeleteUser_Enter, -65, SpringLayout.EAST,
				DeleteUserPanel);
		//When Delete User button is clicked in the home panel
		btnDeleteUser_Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String deleteUserStudentNumber = deleteUser_StdNumber.getText().toString();
				User user;//Create a user object
				for (int i = 0; i < listOfUsers.size(); i++) {
					user = listOfUsers.get(i);//Access to listOfUsers at that point in the array
					if (deleteUserStudentNumber.equals(user.getStudentNumber())) {//To see if the user typed is equal to the user
						deleteUser(listOfUsers.get(i), listOfUsers);//Call DeleteUser
					}
				}
				deleteUser_StdNumber.setText("");//Clear the text field
			}
		});
		DeleteUserPanel.add(btnDeleteUser_Enter);

		button_3 = new JButton("Home");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_DeleteUserPanel.putConstraint(SpringLayout.NORTH, button_3, 10, SpringLayout.NORTH, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.WEST, button_3, 10, SpringLayout.WEST, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.SOUTH, button_3, 46, SpringLayout.NORTH, DeleteUserPanel);
		sl_DeleteUserPanel.putConstraint(SpringLayout.EAST, button_3, 108, SpringLayout.WEST, DeleteUserPanel);
		DeleteUserPanel.add(button_3);

		CreateBookPanel = new JPanel();
		MasterPanel.add(CreateBookPanel, "name_12672129754738");
		SpringLayout sl_CreateBookPanel = new SpringLayout();
		CreateBookPanel.setLayout(sl_CreateBookPanel);

		lblNewLabel_1 = new JLabel("Create Book");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
		CreateBookPanel.add(lblNewLabel_1);

		book_Name = new JTextField();
		CreateBookPanel.add(book_Name);
		book_Name.setColumns(10);

		book_Author = new JTextField();
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_Author, 0, SpringLayout.WEST, book_Name);
		CreateBookPanel.add(book_Author);
		book_Author.setColumns(10);

		book_Category = new JTextField();
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_Category, 0, SpringLayout.WEST, book_Name);
		CreateBookPanel.add(book_Category);
		book_Category.setColumns(10);

		book_ISBN = new JTextField();
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_ISBN, 0, SpringLayout.WEST, book_Name);
		CreateBookPanel.add(book_ISBN);
		book_ISBN.setColumns(10);

		book_Rating = new JTextField();
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_Rating, 0, SpringLayout.WEST, book_Name);
		CreateBookPanel.add(book_Rating);
		book_Rating.setColumns(10);

		book_Cost = new JTextField();
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_Cost, 0, SpringLayout.WEST, book_Name);
		CreateBookPanel.add(book_Cost);
		book_Cost.setColumns(10);

		JLabel lblAuthor = new JLabel("Author");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_Author, -3, SpringLayout.NORTH, lblAuthor);
		CreateBookPanel.add(lblAuthor);

		JLabel lblTitle = new JLabel("Title");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblAuthor, 24, SpringLayout.SOUTH, lblTitle);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblAuthor, 0, SpringLayout.WEST, lblTitle);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_Name, -3, SpringLayout.NORTH, lblTitle);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, book_Name, 49, SpringLayout.EAST, lblTitle);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblTitle, 78, SpringLayout.WEST, CreateBookPanel);
		CreateBookPanel.add(lblTitle);

		JLabel lblCategory = new JLabel("Category");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_Category, -3, SpringLayout.NORTH, lblCategory);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblCategory, 0, SpringLayout.WEST, lblAuthor);
		CreateBookPanel.add(lblCategory);

		JLabel lblISBN = new JLabel("ISBN");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblISBN, 226, SpringLayout.NORTH, CreateBookPanel);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_ISBN, -3, SpringLayout.NORTH, lblISBN);
		sl_CreateBookPanel.putConstraint(SpringLayout.SOUTH, lblCategory, -31, SpringLayout.NORTH, lblISBN);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblISBN, 0, SpringLayout.WEST, lblAuthor);
		CreateBookPanel.add(lblISBN);

		JLabel lblRating = new JLabel("Rating");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblRating, 29, SpringLayout.SOUTH, lblISBN);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_Rating, -3, SpringLayout.NORTH, lblRating);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblRating, 0, SpringLayout.WEST, lblAuthor);
		CreateBookPanel.add(lblRating);

		JLabel lblCost = new JLabel("Cost");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblCost, 30, SpringLayout.SOUTH, lblRating);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, book_Cost, -3, SpringLayout.NORTH, lblCost);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblCost, 0, SpringLayout.WEST, lblAuthor);
		CreateBookPanel.add(lblCost);

		btnCreateBook_Enter = new JButton("Enter");
		sl_CreateBookPanel.putConstraint(SpringLayout.SOUTH, btnCreateBook_Enter, -10, SpringLayout.SOUTH,
				CreateBookPanel);
		sl_CreateBookPanel.putConstraint(SpringLayout.EAST, btnCreateBook_Enter, -41, SpringLayout.EAST,
				CreateBookPanel);
		CreateBookPanel.add(btnCreateBook_Enter);

		button_4 = new JButton("Home");
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, button_4, 10, SpringLayout.NORTH, CreateBookPanel);
		sl_CreateBookPanel.putConstraint(SpringLayout.SOUTH, button_4, -325, SpringLayout.SOUTH, CreateBookPanel);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 11, SpringLayout.NORTH, button_4);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, lblNewLabel_1, 80, SpringLayout.EAST, button_4);
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, lblTitle, 41, SpringLayout.SOUTH, button_4);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, button_4, 10, SpringLayout.WEST, CreateBookPanel);
		sl_CreateBookPanel.putConstraint(SpringLayout.EAST, button_4, 109, SpringLayout.WEST, CreateBookPanel);
		CreateBookPanel.add(button_4);

		bookList = new JTextArea();
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, bookList, -38, SpringLayout.NORTH, book_Name);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, bookList, -230, SpringLayout.EAST, btnCreateBook_Enter);
		sl_CreateBookPanel.putConstraint(SpringLayout.SOUTH, bookList, 0, SpringLayout.SOUTH, book_Cost);
		sl_CreateBookPanel.putConstraint(SpringLayout.EAST, bookList, 0, SpringLayout.EAST, btnCreateBook_Enter);
		CreateBookPanel.add(bookList);

		JButton btn_CreateBook_View = new JButton("View");
		btn_CreateBook_View.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				bookList.setText("");
				Book book;

				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					bookList.append("Title: " + book.getTitle() + "\n" + "Author " + book.getAuthor() + "\n"
							+ "Category " + book.getCategory() + "\n" + "ISBN: " + book.getISBN() + "\n" + "Rating : "
							+ book.getRating() + "\n" + book.getCost() + "\n" + "\n");

				}
			}
		});
		sl_CreateBookPanel.putConstraint(SpringLayout.NORTH, btn_CreateBook_View, 0, SpringLayout.NORTH,
				btnCreateBook_Enter);
		sl_CreateBookPanel.putConstraint(SpringLayout.WEST, btn_CreateBook_View, 10, SpringLayout.WEST, bookList);
		CreateBookPanel.add(btn_CreateBook_View);
		btnCreateBook_Enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String bookName = book_Name.getText().toString();
				String bookAuthor = book_Author.getText().toString();
				String bookCategory = book_Category.getText().toString();
				String bookISBN = book_ISBN.getText().toString().toLowerCase();
				String bookRating = book_Rating.getText().toString();
				String bookCost = book_Cost.getText().toString();

				double bookCostD = Double.parseDouble(bookCost);
				double bookRatingI = Double.parseDouble(bookRating);

				Book book;// Creating a book object
				boolean bookIsTaken = false; //If the book is already created
				// Go through the library's list of students
				for (int i = 0; i < listOfUsers.size(); i++) {//Creating a for loop to go inside the listOfUsers Array List
					book = listOfBooks.get(i); //
					if (bookISBN.equalsIgnoreCase(book.getISBN())) {
						isTaken = true;
						bookList.append("Book Already taken");
					}
				}

				// If the student number isn't already taken
				if (bookIsTaken == false) {
					// Create the student using the entered parameters
					listOfBooks = createBook(bookName, bookAuthor, bookCategory, bookISBN, bookCostD, bookRatingI, false, 
							listOfBooks);
				} else {
					System.out.println("Book is already created");
					book_Name.setText(null);
					book_Author.setText(null);
					book_Category.setText(null);
					book_ISBN.setText(null);
					book_Rating.setText(null);
					book_Cost.setText(null);

				}

				// Setting All Text Fields to Null, so more input can be placed
				book_Name.setText(null);
				book_Author.setText(null);
				book_Category.setText(null);
				book_ISBN.setText(null);
				book_Rating.setText(null);
				book_Cost.setText(null);
			}
		});

		DeleteBookPanel = new JPanel();
		MasterPanel.add(DeleteBookPanel, "name_12672145691554");
		SpringLayout sl_DeleteBookPanel = new SpringLayout();
		DeleteBookPanel.setLayout(sl_DeleteBookPanel);

		lblDeleteBook = new JLabel("Delete Book");
		sl_DeleteBookPanel.putConstraint(SpringLayout.NORTH, lblDeleteBook, 67, SpringLayout.NORTH, DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.WEST, lblDeleteBook, 250, SpringLayout.WEST, DeleteBookPanel);
		DeleteBookPanel.add(lblDeleteBook);

		txtDeleteBook = new JTextField();
		DeleteBookPanel.add(txtDeleteBook);
		txtDeleteBook.setColumns(10);

		lblDeleteBook_ISBN = new JLabel("ISBN");
		sl_DeleteBookPanel.putConstraint(SpringLayout.NORTH, lblDeleteBook_ISBN, 158, SpringLayout.NORTH,
				DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.EAST, lblDeleteBook_ISBN, -403, SpringLayout.EAST,
				DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.NORTH, txtDeleteBook, -3, SpringLayout.NORTH, lblDeleteBook_ISBN);
		sl_DeleteBookPanel.putConstraint(SpringLayout.WEST, txtDeleteBook, 40, SpringLayout.EAST, lblDeleteBook_ISBN);
		DeleteBookPanel.add(lblDeleteBook_ISBN);

		btnDeleteBook_Delete = new JButton("Delete");
		btnDeleteBook_Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String ISBN = txtDeleteBook.getText().toString().toLowerCase();

				Book book;
				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (ISBN.equalsIgnoreCase(book.getISBN()))
						deleteBook(book, listOfBooks);
				}

				txtDeleteBook.setText("");
			}
		});
		sl_DeleteBookPanel.putConstraint(SpringLayout.SOUTH, btnDeleteBook_Delete, -79, SpringLayout.SOUTH,
				DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.EAST, btnDeleteBook_Delete, -74, SpringLayout.EAST,
				DeleteBookPanel);
		DeleteBookPanel.add(btnDeleteBook_Delete);

		button_5 = new JButton("Home");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_DeleteBookPanel.putConstraint(SpringLayout.NORTH, button_5, 10, SpringLayout.NORTH, DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.WEST, button_5, 10, SpringLayout.WEST, DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.SOUTH, button_5, 49, SpringLayout.NORTH, DeleteBookPanel);
		sl_DeleteBookPanel.putConstraint(SpringLayout.EAST, button_5, 112, SpringLayout.WEST, DeleteBookPanel);
		DeleteBookPanel.add(button_5);

		SignIn_SignOut = new JPanel();
		MasterPanel.add(SignIn_SignOut, "name_12672161966436");
		SpringLayout sl_SignIn_SignOut = new SpringLayout();
		SignIn_SignOut.setLayout(sl_SignIn_SignOut);

		lblNewLabel = new JLabel("Sign In(Return Book)");
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, lblNewLabel, 56, SpringLayout.NORTH, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, lblNewLabel, 67, SpringLayout.WEST, SignIn_SignOut);
		SignIn_SignOut.add(lblNewLabel);

		lblCheckOut = new JLabel("Sign Out(Take out book)");
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, lblCheckOut, 5, SpringLayout.NORTH, lblNewLabel);
		SignIn_SignOut.add(lblCheckOut);

		signIn_StdNumber = new JTextField();
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, signIn_StdNumber, 134, SpringLayout.WEST, SignIn_SignOut);
		SignIn_SignOut.add(signIn_StdNumber);
		signIn_StdNumber.setColumns(10);

		signIn_ISBN = new JTextField();
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, signIn_ISBN, 50, SpringLayout.SOUTH, signIn_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, signIn_ISBN, 0, SpringLayout.EAST, signIn_StdNumber);
		SignIn_SignOut.add(signIn_ISBN);
		signIn_ISBN.setColumns(10);

		signIn_DaysOut = new JTextField();
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, signIn_DaysOut, 269, SpringLayout.NORTH, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, signIn_DaysOut, 0, SpringLayout.WEST, signIn_StdNumber);
		SignIn_SignOut.add(signIn_DaysOut);
		signIn_DaysOut.setColumns(10);

		signOut_StdNumber = new JTextField();
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, signOut_StdNumber, -56, SpringLayout.EAST, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, lblCheckOut, 0, SpringLayout.EAST, signOut_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, signOut_StdNumber, 0, SpringLayout.SOUTH, signIn_StdNumber);
		SignIn_SignOut.add(signOut_StdNumber);
		signOut_StdNumber.setColumns(10);

		signOut_ISBN = new JTextField();
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, signOut_ISBN, 0, SpringLayout.NORTH, signIn_ISBN);
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, signOut_ISBN, 0, SpringLayout.WEST, signOut_StdNumber);
		SignIn_SignOut.add(signOut_ISBN);
		signOut_ISBN.setColumns(10);

		lblSignIn_StdNumber = new JLabel("Student Number");
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, lblNewLabel, -23, SpringLayout.NORTH, lblSignIn_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, lblNewLabel, 14, SpringLayout.EAST, lblSignIn_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, lblSignIn_StdNumber, -253, SpringLayout.SOUTH,
				SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, signIn_StdNumber, 6, SpringLayout.SOUTH,
				lblSignIn_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, lblSignIn_StdNumber, 103, SpringLayout.WEST, SignIn_SignOut);
		SignIn_SignOut.add(lblSignIn_StdNumber);

		lblSignIn_ISBN = new JLabel("ISBN");
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, lblSignIn_ISBN, 0, SpringLayout.WEST, signIn_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, lblSignIn_ISBN, -6, SpringLayout.NORTH, signIn_ISBN);
		SignIn_SignOut.add(lblSignIn_ISBN);

		lblSignIn_DaysOut = new JLabel("Days Out(Enter Lost if lost)");
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, lblSignIn_DaysOut, 88, SpringLayout.WEST, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, lblSignIn_DaysOut, -6, SpringLayout.NORTH, signIn_DaysOut);
		SignIn_SignOut.add(lblSignIn_DaysOut);

		lblSignOut_StdNumber = new JLabel("Student Number");
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, lblSignOut_StdNumber, -6, SpringLayout.NORTH,
				signOut_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, lblSignOut_StdNumber, -96, SpringLayout.EAST,
				SignIn_SignOut);
		SignIn_SignOut.add(lblSignOut_StdNumber);

		lblSignOut_ISBN = new JLabel("ISBN");
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, lblSignOut_ISBN, 0, SpringLayout.NORTH, lblSignIn_ISBN);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, lblSignOut_ISBN, -119, SpringLayout.EAST, SignIn_SignOut);
		SignIn_SignOut.add(lblSignOut_ISBN);

		JButton btnSignIn = new JButton("Sign In");
		btnSignIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {// ///////////////////////////////////////////////////////////////////////////////////////////
				String signInStudentNumber = signIn_StdNumber.getText().toString();
				String signInISBN = signIn_ISBN.getText().toString();
				String signInDaysOut = signIn_DaysOut.getText().toString().toLowerCase();
				double studentFine = 0;

				User user;
				Book book;
				int userValue = 0;
				int bookValue = 0;
				for (int i = 0; i < listOfUsers.size(); i++) {
					user = listOfUsers.get(i);
					if (signInStudentNumber.equals(user.getStudentNumber()))
						userValue = i;
				}

				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (signInISBN.equals(book.getISBN()))
						bookValue = i;
				}
				// Returns the appropriate user and book that was put in the
				// text field
				signIn(listOfUsers.get(userValue), listOfBooks.get(bookValue));

				if (signInDaysOut.equalsIgnoreCase("lost")) {
					studentFine = listOfBooks.get(bookValue).getCost();
					(listOfBooks.get(bookValue)).setBookOut(false);
				}

				else if (!(signInDaysOut.equalsIgnoreCase("lost"))) {
					double daysOut = Double.parseDouble(signInDaysOut);
					if (daysOut > 14) {
						studentFine = ((daysOut) - 14) * 0.10;
						(listOfBooks.get(bookValue)).setBookOut(false);
					}
				}
				listOfUsers.get(userValue).setFines(studentFine);

				signIn_StdNumber.setText("");
				signIn_ISBN.setText("");
				signIn_DaysOut.setText("");
				

			}
		});
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, btnSignIn, 24, SpringLayout.SOUTH, signIn_DaysOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, btnSignIn, 0, SpringLayout.EAST, signIn_StdNumber);
		SignIn_SignOut.add(btnSignIn);

		JButton btnSignOut = new JButton("Sign Out");
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ISBN = signOut_ISBN.getText().toString().toUpperCase();
				String stdNumber = signOut_StdNumber.getText().toString();

				Book book;
				Book bookSend = null;
				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (book.getISBN().equals(ISBN)) {
						bookSend = book;
					}
				}
				User user;
				User userSend = null;
				for (int i = 0; i < listOfUsers.size(); i++) {
					user = listOfUsers.get(i);
					if (user.getStudentNumber().equals(stdNumber))
						userSend = user;
				}
				
				if (numberOfBooksOut < 3 && userSend.getFines() < 5 && bookSend.getBookOut()==false) {
					numberOfBooksOut++;
					signOut(userSend, bookSend);
				
				System.out.println(bookSend.getBookOut());
				} else
					userList.append("You either have more than 3 books out" + "\n" + "or fine greater than $5");
				signOut_StdNumber.setText("");
				signOut_ISBN.setText("");

			}
		});
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, btnSignOut, 0, SpringLayout.WEST, signOut_StdNumber);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, btnSignOut, 0, SpringLayout.SOUTH, btnSignIn);
		SignIn_SignOut.add(btnSignOut);

		button_6 = new JButton("Home");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_SignIn_SignOut.putConstraint(SpringLayout.NORTH, button_6, 10, SpringLayout.NORTH, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.WEST, button_6, 10, SpringLayout.WEST, SignIn_SignOut);
		sl_SignIn_SignOut.putConstraint(SpringLayout.SOUTH, button_6, -13, SpringLayout.NORTH, lblNewLabel);
		sl_SignIn_SignOut.putConstraint(SpringLayout.EAST, button_6, 113, SpringLayout.WEST, SignIn_SignOut);
		SignIn_SignOut.add(button_6);

		LookUpBooksPanel = new JPanel();
		MasterPanel.add(LookUpBooksPanel, "name_13791397080275");
		SpringLayout sl_LookUpBooksPanel = new SpringLayout();
		LookUpBooksPanel.setLayout(sl_LookUpBooksPanel);

		categorySearch = new JTextField();
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, categorySearch, 83, SpringLayout.WEST, LookUpBooksPanel);
		LookUpBooksPanel.add(categorySearch);
		categorySearch.setColumns(10);

		authorSearch = new JTextField();
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, authorSearch, 83, SpringLayout.WEST, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.EAST, authorSearch, 0, SpringLayout.EAST, categorySearch);
		LookUpBooksPanel.add(authorSearch);
		authorSearch.setColumns(10);

		btnCategory = new JButton("Search by Category");
		btnCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String category = categorySearch.getText().toString().toLowerCase();
				Book book;

				textArea_SearchBook.setText("");

				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (category.equalsIgnoreCase(book.getCategory())) {
						textArea_SearchBook.append("The book: " + book.getTitle() + " by " + book.getAuthor() + "\n");
					}
				}
			}
		});
		sl_LookUpBooksPanel.putConstraint(SpringLayout.NORTH, btnCategory, 119, SpringLayout.NORTH, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, btnCategory, 80, SpringLayout.WEST, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, categorySearch, -26, SpringLayout.NORTH, btnCategory);
		LookUpBooksPanel.add(btnCategory);

		btnAuthor = new JButton("Search by Author");
		btnAuthor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String author = authorSearch.getText().toString().toLowerCase();
				Book book;

				textArea_SearchBook.setText("");

				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (author.equalsIgnoreCase(book.getCategory())) {
						textArea_SearchBook.append("The book: " + book.getTitle() + " by " + book.getAuthor() + "\n");
					}
				}
			}
		});
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, authorSearch, -27, SpringLayout.NORTH, btnAuthor);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, btnAuthor, 0, SpringLayout.WEST, categorySearch);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, btnAuthor, -44, SpringLayout.SOUTH, LookUpBooksPanel);
		LookUpBooksPanel.add(btnAuthor);

		sl_LookUpBooksPanel.putConstraint(SpringLayout.EAST, categorySearch, -48, SpringLayout.WEST,
				textArea_SearchBook);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.NORTH, textArea_SearchBook, 27, SpringLayout.NORTH,
				LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, textArea_SearchBook, -10, SpringLayout.SOUTH,
				LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, textArea_SearchBook, -353, SpringLayout.EAST,
				LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.EAST, textArea_SearchBook, -10, SpringLayout.EAST,
				LookUpBooksPanel);
		LookUpBooksPanel.add(textArea_SearchBook);

		button = new JButton("Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_LookUpBooksPanel.putConstraint(SpringLayout.NORTH, button, 10, SpringLayout.NORTH, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, button, 10, SpringLayout.WEST, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, button, 51, SpringLayout.NORTH, LookUpBooksPanel);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.EAST, button, 99, SpringLayout.WEST, LookUpBooksPanel);
		LookUpBooksPanel.add(button);

		lblNewLabel_3 = new JLabel("Category");
		sl_LookUpBooksPanel.putConstraint(SpringLayout.NORTH, lblNewLabel_3, 6, SpringLayout.SOUTH, button);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.EAST, lblNewLabel_3, 0, SpringLayout.EAST, button);
		LookUpBooksPanel.add(lblNewLabel_3);

		lblCategory_1 = new JLabel("Author");
		sl_LookUpBooksPanel.putConstraint(SpringLayout.WEST, lblCategory_1, 0, SpringLayout.WEST, lblNewLabel_3);
		sl_LookUpBooksPanel.putConstraint(SpringLayout.SOUTH, lblCategory_1, -6, SpringLayout.NORTH, authorSearch);
		LookUpBooksPanel.add(lblCategory_1);

		CompareBooksPanel = new JPanel();
		MasterPanel.add(CompareBooksPanel, "name_13795278961896");
		SpringLayout sl_CompareBooksPanel = new SpringLayout();
		CompareBooksPanel.setLayout(sl_CompareBooksPanel);

		textField_ISBN1 = new JTextField();
		CompareBooksPanel.add(textField_ISBN1);
		textField_ISBN1.setColumns(10);

		textField_ISBN2 = new JTextField();
		sl_CompareBooksPanel.putConstraint(SpringLayout.NORTH, textField_ISBN2, 0, SpringLayout.NORTH, textField_ISBN1);
		CompareBooksPanel.add(textField_ISBN2);
		textField_ISBN2.setColumns(10);

		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, txtArea_CompareBooks, 94, SpringLayout.WEST,
				CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.EAST, txtArea_CompareBooks, -97, SpringLayout.EAST,
				CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.EAST, textField_ISBN2, 0, SpringLayout.EAST,
				txtArea_CompareBooks);
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, textField_ISBN1, 0, SpringLayout.WEST,
				txtArea_CompareBooks);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, textField_ISBN1, -86, SpringLayout.NORTH,
				txtArea_CompareBooks);
		sl_CompareBooksPanel.putConstraint(SpringLayout.NORTH, txtArea_CompareBooks, -143, SpringLayout.SOUTH,
				CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, txtArea_CompareBooks, -23, SpringLayout.SOUTH,
				CompareBooksPanel);
		CompareBooksPanel.add(txtArea_CompareBooks);

		JLabel lblCompareTwoBooks = new JLabel("Compare Two Books");
		sl_CompareBooksPanel.putConstraint(SpringLayout.NORTH, lblCompareTwoBooks, 37, SpringLayout.NORTH,
				CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, lblCompareTwoBooks, 203, SpringLayout.WEST,
				CompareBooksPanel);
		lblCompareTwoBooks.setFont(new Font("Tahoma", Font.PLAIN, 20));
		CompareBooksPanel.add(lblCompareTwoBooks);

		JLabel lblIsbn = new JLabel("ISBN");
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, lblIsbn, 0, SpringLayout.WEST, textField_ISBN1);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, lblIsbn, -6, SpringLayout.NORTH, textField_ISBN1);
		CompareBooksPanel.add(lblIsbn);

		JLabel label = new JLabel("ISBN");
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, label, 0, SpringLayout.WEST, textField_ISBN2);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, label, -6, SpringLayout.NORTH, textField_ISBN2);
		CompareBooksPanel.add(label);

		btnCompare = new JButton("Compare");
		btnCompare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ISBN1 = textField_ISBN1.getText().toString().toLowerCase();
				String ISBN2 = textField_ISBN2.getText().toString().toLowerCase();

				Book book;
				Book bookValue1 = null;
				Book bookValue2 = null;

				for (int i = 0; i < listOfBooks.size(); i++) {
					book = listOfBooks.get(i);
					if (ISBN1.equalsIgnoreCase(book.getISBN())) {
						bookValue1 = book;
					}
					if (ISBN2.equalsIgnoreCase(book.getISBN())) {
						bookValue2 = book;
					}
				}
				txtArea_CompareBooks.setText("");
				if (bookValue1.getRating() > bookValue2.getRating()) {
					txtArea_CompareBooks
							.append(bookValue1.getTitle() + " is a better book than " + bookValue2.getTitle());
				} else if (bookValue2.getRating() > bookValue1.getRating()) {
					txtArea_CompareBooks
							.append(bookValue2.getTitle() + " is a better book than " + bookValue1.getTitle());
				} else if (bookValue1.getRating() == bookValue2.getRating()) {
					txtArea_CompareBooks.append(
							bookValue1.getTitle() + " and " + bookValue2.getTitle() + " have the same book rating");
				}
			}
		});
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, btnCompare, 246, SpringLayout.WEST, CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, btnCompare, -25, SpringLayout.NORTH,
				txtArea_CompareBooks);
		CompareBooksPanel.add(btnCompare);

		button_1 = new JButton("Home");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < 2; i++)
					MasterPanel.add(homePanel).setVisible(true);
			}
		});
		sl_CompareBooksPanel.putConstraint(SpringLayout.NORTH, button_1, 10, SpringLayout.NORTH, CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.WEST, button_1, 10, SpringLayout.WEST, CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.SOUTH, button_1, 49, SpringLayout.NORTH, CompareBooksPanel);
		sl_CompareBooksPanel.putConstraint(SpringLayout.EAST, button_1, 0, SpringLayout.EAST, lblIsbn);
		CompareBooksPanel.add(button_1);
		// When enter is clicked in the UserPanel
		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String studentNumber = std_Number.getText().toString(); //Convert the textfield text into a usable string
				String studentFName = std_FName.getText().toString();
				String studentLName = std_LName.getText().toString();
				
				User user;
				// Go through the library's list of students
				for (int i = 0; i < listOfUsers.size(); i++) {
					user = listOfUsers.get(i);
					if (studentNumber.equals(user.getStudentNumber())) {
						isTaken = true;
						userList.append("User Already taken");//Make it appear on the textarea userList
					}
				}
				// If the student number isn't already taken
				if (isTaken == false) {
					// Create the student using the entered parameters
					listOfUsers = createUser(studentNumber, studentFName, studentLName, 0, listOfUsers);
				}
				// Setting All Text Fields to Null, so more input can be placed
				std_Number.setText(null);
				std_FName.setText(null);
				std_LName.setText(null);
			}
		});
	}

    //Method that creates a student object and adds it to the array list
    //@param: a string variable for the first name of the student
    //@param: a string variable for the last name of the student
    //@param: an integer variable to contain the unique student number of the student
    //@param: a double variable containing the balance of the student for overdue books
    //@param: listOfStudents: the array that the student will be added to
    //@returns: returns the arraylist with the new student added to it
	public static ArrayList<User> createUser(String studentNumber, String firstName, String lastName, double fines,
			ArrayList<User> listOfUsers) {
		User user = new User(studentNumber, firstName, lastName, fines);
		listOfUsers.add(user);
		return listOfUsers;
	}

    //Method that removes a student from the arraylist
    //@param:student: student to be removed from the array list
    //@param: listOfStudents: the array list that the student will be removed from
    //@returns: returns the new array with the student removed
	public static ArrayList<User> deleteUser(User user, ArrayList<User> listOfUsers) {
		listOfUsers.remove(user);
		return listOfUsers;
	}

    //Method that creates a new book and inserts it into the library array
    //@param: title: string variable for the title of the book
    //@param: author: string variable for author of book
    //@param: rating: double variable of reader rating of the book 
    //@param: cost: double variable of the cost of the book
    //@param: ISBN: String variable of book's ISBN code
    //@param: copies: int variable of number of available copies of book
    //@param: numBooks: total number of books in the library
    //@param: library: arraylist to add the library book to
    //@returns: returns the new arraylist that the book was added to
	public static ArrayList<Book> createBook(String title, String author, String ISBN, String category, double cost,
			double rating, boolean bookOut, ArrayList<Book> listOfBooks) {
		Book book = new Book(title, author, ISBN, category, cost, rating, bookOut);
		listOfBooks.add(book);
		return listOfBooks;
	}

    //Method that removes a book from the arraylist
    //@param: book: the book to be removed from the arraylist
    //@param: listOfBooks: the array list that the book will be removed from
    //@returns: returns the array with the book removed
	public static ArrayList<Book> deleteBook(Book book, ArrayList<Book> listOfBooks) {
		listOfBooks.remove(book);
		return listOfBooks;
	}

    //Method that takes a book from the student, removes it from the student and adds it to the library
    //@param: student: student that the book will be taken from
    //@param: book: book that will be returned to the library
	public static User signIn(User user, Book book) {// RETURNING BOOK BACK TO
														// SCHOOL
		user.removeBook(book);
		return user;
	}
	
    //Method that adds a book to the student object
    //@param: Student variable for the book to be stored in
    //@param: Book variable to store inside the student
	public static void signOut(User user, Book book) {
		book.setBookOut(true);
		user.addBook(book);
	}
}
