//Tanishk Nalamolu
//ICS4U0
//10/17/2016
//Library Assignment User Class

import java.util.ArrayList;

public class User {

	private String studentNumber; //Users Student Number
	private String firstName;//Users FirstName
	private String lastName;//Users last Name
	private double fines;// Should be double
    //an arrayList of books borrowed by the student
	public ArrayList<Book> books = new ArrayList<Book>();

    //Student constructor that assigns a first name, last name, student number, and library balance
    //@param: a string variable for the first name of the student
    //@param: a string variable for the last name of the student
    //@param: an integer variable to contain the unique student number of the student
    //@param: a double variable containing the balance of the student for overdue books
	public User(String stNumber, String fName, String lName, double fines) {
		this.studentNumber = stNumber;
		this.firstName = fName;
		this.lastName = lName;
		this.fines = fines;
	}

    //Method that returns the student number of the given student
    //@return: returns the student number of the given student
	public String getStudentNumber() {
		return studentNumber;
	}

    //Method that returns the last name of the given student
    //@return: returns the last name of the given student
	public String getLastName() {
		return lastName;
	}

    //Method that returns the first name of the given student
    //@return: returns the first name of the given student
	public String getFirstName() {
		return firstName;
	}

    //Method that takes in a new balance for the student and changes it
	//@param: fine that is set in the program
	public void setFines(double fines) {
		this.fines = fines;
	}

    //Method that returns the current owed library balance of the given student
    //@return: returns the current owed library balance of the given student
	public double getFines() {
		return fines;
	}

	//Removes a book to the ArrayList
	//@param: The appropriate book that is being removed from the books ArrayList
	public void removeBook(Book book) {
		books.remove(book);
	}

	//Adds a book to the ArrayList
	//@param: The appropriate book that is being added to the books ArrayList
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		books.add(book);
	}

}
